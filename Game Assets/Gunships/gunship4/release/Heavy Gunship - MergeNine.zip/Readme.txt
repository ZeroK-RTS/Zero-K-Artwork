AF

There are 2 versions here.
The former version looks as you saw it in the forums.
The latter version may be more useful to you, as it has slightly taller turrets, the UV map is adjusted to suit this, and the teamcolour shape is a bit different.
I've also added in controls to help you export a texture 2 should you need it.

Any problems let me know

Russ